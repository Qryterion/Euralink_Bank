
package config

import (
    "os"
)

var (
    GoldMoneyAPIKey = os.Getenv("GOLDMONEY_API_KEY")
    BullionVaultAPIKey = os.Getenv("BULLIONVAULT_API_KEY")
)
