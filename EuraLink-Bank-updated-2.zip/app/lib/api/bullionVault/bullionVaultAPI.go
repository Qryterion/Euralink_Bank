
package bullionvault

import (
    "encoding/json"
    "net/http"
    "fmt"
)

const apiURL = "https://api.bullionvault.com"

type BullionVaultResponse struct {
    // Define the response structure
}

func GetBullionVaultData(apiKey string) (*BullionVaultResponse, error) {
    req, err := http.NewRequest("GET", fmt.Sprintf("%s/data", apiURL), nil)
    if err != nil {
        return nil, err
    }
    req.Header.Set("Authorization", "Bearer "+apiKey)

    client := &http.Client{}
    resp, err = client.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    var response BullionVaultResponse
    if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
        return nil, err
    }

    return &response, nil
}
