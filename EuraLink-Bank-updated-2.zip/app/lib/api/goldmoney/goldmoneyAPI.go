
package goldmoney

import (
    "encoding/json"
    "net/http"
    "fmt"
)

const apiURL = "https://api.goldmoney.com"

type GoldMoneyResponse struct {
    // Define the response structure
}

func GetGoldMoneyData(apiKey string) (*GoldMoneyResponse, error) {
    req, err := http.NewRequest("GET", fmt.Sprintf("%s/data", apiURL), nil)
    if err != nil {
        return nil, err
    }
    req.Header.Set("Authorization", "Bearer "+apiKey)

    client := &http.Client{}
    resp, err := client.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    var response GoldMoneyResponse
    if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
        return nil, err
    }

    return &response, nil
}
