
package utils

import (
    "fmt"
    "EuraLink/app/lib/api/goldmoney"
    "EuraLink/app/lib/api/bullionvault"
    "EuraLink/integration/config"
)

func SyncData() {
    goldData, err := goldmoney.GetGoldMoneyData(config.GoldMoneyAPIKey)
    if err != nil {
        fmt.Println("Error fetching GoldMoney data:", err)
        return
    }
    fmt.Println("GoldMoney Data:", goldData)

    bullionData, err := bullionvault.GetBullionVaultData(config.BullionVaultAPIKey)
    if err != nil {
        fmt.Println("Error fetching BullionVault data:", err)
        return
    }
    fmt.Println("BullionVault Data:", bullionData)
}
